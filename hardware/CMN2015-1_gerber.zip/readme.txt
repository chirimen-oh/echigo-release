This is the gerber data of CMN2015-1 which is the first board computer design that the CHIRIMEN Open Hardware project developed. You should also look at the PDF data of this named CMN2015-1_printPattern.pdf altogether. 

This information is published under the CHIRMEN license.  See http://chirimen.org/license/
